from abc import ABC, abstractmethod


class IAbsorber(ABC):
    """Interface contract for all absorber implementations."""

    @abstractmethod
    def get_mua(self, wavelength: float) -> float:
      """Returns Mua (absorption coefficient) for a given wavelength."""
      pass
