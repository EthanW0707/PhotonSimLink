import numpy as np

class MieScatterer:
    """
    This class implements the formulation by Craig F. Bohren, Donald R. Huffman
    'Absorption and Scattering of Light by Small Particles', Wiley Sci., 1983
    Python equivalent of Vts.SpectralMapping.MieScatterer
    """
    ANGLES = 361
    N_ANGLES = 2 * ANGLES - 1
    D_THETA = (np.pi / 2) / (ANGLES - 1)

    class MieScatteringParameters:
        def __init__(self):
            self.q = None
            self.s1 = None
            self.s2 = None
            self.s11 = None
            self.g = 0.0

    def __init__(self, particle_radius=0.5, particle_refractive_index=1.4, medium_refractive_index=1.0, volume_fraction=0.01):
        self._particle_radius = particle_radius
        self._particle_refractive_index_mismatch = particle_refractive_index
        self._medium_refractive_index_mismatch = medium_refractive_index
        self._volume_fraction = volume_fraction
        self.mie_scatt_params = None

    @property
    def scatterer_type(self) -> str:
        return "Mie"

    @property
    def particle_radius(self) -> float:
        return self._particle_radius

    @particle_radius.setter
    def particle_radius(self, value: float):
        self._particle_radius = value

    @property
    def particle_refractive_index_mismatch(self) -> float:
        return self._particle_refractive_index_mismatch

    @particle_refractive_index_mismatch.setter
    def particle_refractive_index_mismatch(self, value: float):
        self._particle_refractive_index_mismatch = value

    @property
    def medium_refractive_index_mismatch(self) -> float:
        return self._medium_refractive_index_mismatch

    @medium_refractive_index_mismatch.setter
    def medium_refractive_index_mismatch(self, value: float):
        self._medium_refractive_index_mismatch = value

    @property
    def volume_fraction(self) -> float:
        return self._volume_fraction

    @volume_fraction.setter
    def volume_fraction(self, value: float):
        if value > 1.0:
            value = 1.0
        elif value < 0.0:
            value = 0.0
        self._volume_fraction = value

    def get_g(self, wavelength: float) -> float:
        """Returns the anisotropy coefficient for a given wavelength."""
        self.mie_scatt_params = self._bohren_huffman_mie(wavelength)
        return self.mie_scatt_params.g

    def get_mus(self, wavelength: float) -> float:
        """Returns the scattering coefficient for a given wavelength."""
        self.mie_scatt_params = self._bohren_huffman_mie(wavelength)
        q_sca = self.mie_scatt_params.q[0]
        mus = self._volume_fraction * q_sca / ((4.0 / 3.0) * self._particle_radius * 1e-3)
        return mus

    def get_musp(self, wavelength: float) -> float:
        """Returns the reduced scattering coefficient for a given wavelength."""
        mus = self.get_mus(wavelength)
        g = self.get_g(wavelength)
        return mus * (1.0 - g)

    def _get_size_parameter(self, wavelength: float) -> float:
        return 1000 * 2.0 * np.pi * self._particle_radius * self._medium_refractive_index_mismatch / wavelength

    def _bohren_huffman_mie(self, wavelength: float):
        angles = self.ANGLES
        n_angles = self.N_ANGLES
        d_theta = self.D_THETA

        amu = np.zeros(angles)
        theta = np.zeros(angles)
        tau = np.zeros(angles)
        pi = np.zeros(angles)
        pi0 = np.zeros(angles)
        pi1 = np.zeros(angles)
        s1 = np.zeros(n_angles, dtype=complex)
        s2 = np.zeros(n_angles, dtype=complex)

        size_parameter = self._get_size_parameter(wavelength)
        n_stop = int(size_parameter + 4.0 * (size_parameter ** (1.0 / 3.0)) + 2.0)

        n_sphere = self._particle_refractive_index_mismatch
        n_medium = self._medium_refractive_index_mismatch
        refrel = complex(n_sphere, 0.0) / complex(n_medium, 0.0)

        ym = abs(size_parameter * abs(refrel))
        n_mx = int(ym > n_stop if isinstance(ym, bool) else (ym + 15 if ym > n_stop else n_stop + 15))

        d = np.zeros(n_mx + 1, dtype=complex)
        for p in range(n_mx, 0, -1):
            z = complex(p + 1) / (size_parameter * refrel)
            d[p - 1] = z - 1.0 / (d[p] + z)

        for i in range(angles):
            theta[i] = i * d_theta
            amu[i] = np.cos(theta[i])
            pi0[i] = 0.0
            pi1[i] = 1.0

        psi0 = np.cos(size_parameter)
        psi1 = np.sin(size_parameter)
        chi0 = -psi1
        chi1 = psi0
        xi1 = complex(psi1, -chi1)

        q_sca = 0.0

        for n in range(int(n_stop)):
            rn = float(n + 1)
            fn = (2.0 * rn + 1.0) / (rn * (rn + 1.0))
            psi = (2.0 * rn - 1.0) * psi1 / size_parameter - psi0
            chi = (2.0 * rn - 1.0) * chi1 / size_parameter - chi0
            xi = complex(psi, -chi)

            an = ((d[n] / refrel + rn / size_parameter) * psi - psi1) / \
                 ((d[n] / refrel + rn / size_parameter) * xi - xi1)
            bn = ((refrel * d[n] + rn / size_parameter) * psi - psi1) / \
                 ((refrel * d[n] + rn / size_parameter) * xi - xi1)

            q_sca += (2.0 * rn + 1.0) * (abs(an) ** 2 + abs(bn) ** 2)

            p_val = (-1.0) ** (rn - 1.0)
            t_val = (-1.0) ** rn

            for j in range(angles):
                jj = n_angles - 1 - j
                pi[j] = pi1[j]
                tau[j] = rn * amu[j] * pi[j] - (rn + 1.0) * pi0[j]

                s1[j] += fn * (an * pi[j] + bn * tau[j])
                s2[j] += fn * (an * tau[j] + bn * pi[j])
                if j == jj:
                    continue
                s1[jj] += fn * (p_val * an * pi[j] + t_val * bn * tau[j])
                s2[jj] += fn * (t_val * an * tau[j] + p_val * bn * pi[j])

            psi0 = psi1
            psi1 = psi
            chi0 = chi1
            chi1 = chi
            xi1 = complex(psi1, -chi1)

            rn += 1.0
            for j in range(angles):
                pi1[j] = ((2.0 * rn - 1.0) * amu[j] * pi[j] - rn * pi0[j]) / (rn - 1.0)
                pi0[j] = pi[j]

        params = self.MieScatteringParameters()
        params.q = np.zeros(3)
        params.q[0] = q_sca * 2.0 / (size_parameter ** 2)
        params.q[1] = (4.0 * s1[0].real) / (size_parameter ** 2)
        params.q[2] = 4.0 / (size_parameter ** 2) * (abs(s1[n_angles - 1]) ** 2)

        params.s1 = s1
        params.s2 = s2
        params.s11 = np.zeros(n_angles)

        g_numerator = 0.0
        g_denominator = 0.0
        for j in range(n_angles):
            cost = np.cos(j * d_theta)
            sint = np.sqrt(1.0 - cost * cost)
            params.s11[j] = 0.5 * (abs(params.s1[j]) ** 2 + abs(params.s2[j]) ** 2)
            g_numerator += params.s11[j] * cost * 2 * np.pi * sint * d_theta
            g_denominator += params.s11[j] * 2 * np.pi * sint * d_theta

        params.g = g_numerator / g_denominator if g_denominator != 0 else 0.0
        return params
