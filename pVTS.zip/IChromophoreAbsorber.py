from typing import Protocol

class IAbsorber(Protocol):
    """Protocol for absorber components."""
    def get_mua(self, wavelength: float) -> float:
        ...

class IChromophoreAbsorber(IAbsorber, Protocol):
    """A general interface for a chromophore absorber."""

    @property
    def name(self) -> str:
        ...

    @name.setter
    def name(self, value: str):
        ...

    @property
    def concentration(self) -> float:
        ...

    @concentration.setter
    def concentration(self, value: float):
        ...

    @property
    def chromophore_coefficient_type(self):
        ...

    @chromophore_coefficient_type.setter
    def chromophore_coefficient_type(self, value):
        ...
