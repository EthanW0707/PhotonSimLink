from typing import Protocol

class ISpectrum(Protocol):
    """General interface for any spectrum (ie. ChromophoreSpectrum or ScatteringSpectrum)."""

    @property
    def name(self) -> str:
        ...

    @name.setter
    def name(self, value: str):
        ...

    def get_spectral_value(self, wavelength: float) -> float:
        """Returns the spectral value for a specific wavelength."""
        ...

    @property
    def chromophore_coefficient_type(self):
        ...

    @chromophore_coefficient_type.setter
    def chromophore_coefficient_type(self, value):
        ...

    @property
    def absorption_coefficient_unit(self):
        ...

    @absorption_coefficient_unit.setter
    def absorption_coefficient_unit(self, value):
        ...

    @property
    def molar_unit(self):
        ...

    @molar_unit.setter
    def molar_unit(self, value):
        ...

    @property
    def wavelength_unit(self):
        ...

    @wavelength_unit.setter
    def wavelength_unit(self, value):
        ...
