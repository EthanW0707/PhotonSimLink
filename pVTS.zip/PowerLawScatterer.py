class PowerLawScatterer:
    """
    Power law scatterer ported from VTS.
    Calculates mus' based on power law parameters: mus' = a * (wavelength / lambda0)^(-b) + c * (wavelength / lambda0)^(-d)
    """
    def __init__(self, a=1.0, b=0.1, c=0.0, d=0.0, lambda0=1000.0):
        if hasattr(a, "name") or not isinstance(a, (int, float)):
            tissue_type = a
            params = self._get_default_params(tissue_type)
            self._a = params["a"]
            self._b = params["b"]
            self._c = params["c"]
            self._d = params["d"]
            self._lambda0 = params["lambda0"]
        else:
            self._a = float(a)
            self._b = float(b) if b is not None else 0.1
            self._c = float(c) if c is not None else 0.0
            self._d = float(d) if d is not None else 0.0
            self._lambda0 = float(lambda0) if lambda0 is not None else 1000.0

    def _get_default_params(self, tissue_type):
        """
        VTS default scattering power law parameters matching the C# switch statement.
        """
        t_name = str(getattr(tissue_type, "name", tissue_type))

        defaults = {
            "Skin": {"a": 1.2, "b": 1.42, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
            "BreastPreMenopause": {"a": 0.67, "b": 0.95, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
            "BreastPostMenopause": {"a": 0.72, "b": 0.58, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
            "BrainWhiteMatter": {"a": 3.56, "b": 0.84, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
            "BrainGrayMatter": {"a": 0.56, "b": 1.36, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
            "Liver": {"a": 0.84, "b": 0.55, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
            "Custom": {"a": 1.0, "b": 0.1, "c": 0.0, "d": 0.0, "lambda0": 1000.0},
        }
        return defaults.get(t_name, {"a": 1.0, "b": 0.1, "c": 0.0, "d": 0.0, "lambda0": 1000.0})

    @property
    def scatterer_type(self) -> str:
        return "PowerLaw"

    @property
    def a(self) -> float:
        return self._a

    @a.setter
    def a(self, value: float):
        self._a = value

    @property
    def b(self) -> float:
        return self._b

    @b.setter
    def b(self, value: float):
        self._b = value

    @property
    def c(self) -> float:
        return self._c

    @c.setter
    def c(self, value: float):
        self._c = value

    @property
    def d(self) -> float:
        return self._d

    @d.setter
    def d(self, value: float):
        self._d = value

    @property
    def lambda0(self) -> float:
        return self._lambda0

    @lambda0.setter
    def lambda0(self, value: float):
        self._lambda0 = value

    def get_musp(self, wavelength: float) -> float:
        """Returns reduced scattering coefficient (mus') for a given wavelength using the power-law equation."""
        wavelength = float(wavelength)
        term1 = self._a * ((wavelength / self._lambda0) ** -self._b)
        term2 = self._c * ((wavelength / self._lambda0) ** -self._d)
        return float(term1 + term2)

    def get_g(self, wavelength: float) -> float:
        """Returns fixed anisotropy factor (g) of 0.8 matching C# implementation."""
        return 0.8

    def get_mus(self, wavelength: float) -> float:
        """Returns physical scattering coefficient (mus = mus' / (1 - g))."""
        musp = self.get_musp(wavelength)
        g = self.get_g(wavelength)
        return float(musp / (1.0 - g))
