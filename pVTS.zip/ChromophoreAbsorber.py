import os
import numpy as np
class chrom_absorber:
    def __init__(self, *chromophore_names):
        """
        Initializes a collection of chromophore absorbers supporting multiple names
        (e.g., chrom_absorber(ChromophoreType.HbO2, ChromophoreType.Hb) or strings)
        integrated with the global SpectralDatabase.
        """
        self.chromophore_names = [
            c.name if hasattr(c, "name") else str(c)
            for c in chromophore_names
        ]

    def get_mua(self, wavelength: float, concentrations=None) -> float:
        """
        Looks up or interpolates wavelength in the SpectralDatabase and computes total mua.
        """
        if concentrations is None:
            concentrations = {name: 1.0 for name in self.chromophore_names}

        total_mua = 0.0

        for name in self.chromophore_names:
            key = name.strip()
            try:
                ext_coeff = SpectralDatabase.get_extinction_coefficient(key, wavelength)
            except KeyError:
                ext_coeff = 0.0

            conc = concentrations.get(key, 1.0)
            total_mua += conc * ext_coeff

        return float(total_mua)
