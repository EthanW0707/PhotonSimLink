from enum import Enum
from typing import Any, Dict, List, Optional, Union
import numpy as np
from .ChromophoreAbsorber import chrom_absorber
from .PowerLawScatterer import PowerLawScatterer
from .IntralipidScatterer import IntralipidScatterer
from .MieScatterer import MieScatterer

class OpticalProperties:
    """Class to represent optical properties (mua, musp, g, n)."""
    def __init__(self, mua: float, musp: float, g: float, n: float):
        self.mua = mua
        self.musp = musp
        self.g = g
        self.n = n

    def __str__(self) -> str:
        return f"OpticalProperties(mua={self.mua}, musp={self.musp}, g={self.g}, n={self.n})"

class ChromophoreType(Enum):
    Hb = 1
    HbO2 = 2
    H2O = 3
    Fat = 4
    Melanin = 5
    Nigrosin = 6

class TissueType(Enum):
    Skin = 1
    BreastPreMenopause = 2
    BreastPostMenopause = 3
    BrainWhiteMatter = 4
    BrainGrayMatter = 5
    Liver = 6
    IntralipidPhantom = 7
    PolystyreneSpherePhantom = 8
    Custom = 9


class Tissue:
    """Class to represent a tissue."""

    def __init__(
        self,
        absorbers: Optional[List[Any]] = None,
        scatterer: Optional[Any] = None,
        name: Optional[str] = None,
        n: Optional[float] = 1.4,
        tissue_type: Optional[TissueType] = None
    ):
        if tissue_type is not None:
            self.tissue_type = tissue_type
            self.set_predefined_tissue_definitions(tissue_type)
            self.name = tissue_type.name
        else:
            self.absorbers = absorbers if absorbers is not None else []
            self.scatterer = scatterer
            self.name = name if name is not None else "CustomTissue"
            self.n = n if n is not None else 1.4
            self.tissue_type = TissueType.Custom

    @property
    def scatterer_type(self) -> Optional[Any]:
        """Scatterer type."""
        if self.scatterer and hasattr(self.scatterer, "scatterer_type"):
            return self.scatterer.scatterer_type
        return None

    def set_predefined_tissue_definitions(self, tissue_type: TissueType):
        """Set the absorbers and the scatterer for the specified tissue type."""
        self.tissue_type = tissue_type
        self.absorbers = TissueProvider.create_absorbers(tissue_type)
        self.scatterer = TissueProvider.create_scatterer(tissue_type)
        self.n = 1.4

    def __str__(self) -> str:
        return self.name

    def get_mua(self, wavelength: float) -> float:
        """Returns Mua (absorption coefficient) for a given wavelength."""
        return sum(abs_item.get_mua(wavelength) for abs_item in self.absorbers)

    def get_musp(self, wavelength: float) -> float:
        """Returns the reduced scattering coefficient for a given wavelength."""
        if self.scatterer and hasattr(self.scatterer, "get_musp"):
            return self.scatterer.get_musp(wavelength)
        return 0.0

    def get_g(self, wavelength: float) -> float:
        """Returns the anisotropy coefficient for a given wavelength."""
        if self.scatterer and hasattr(self.scatterer, "get_g"):
            return self.scatterer.get_g(wavelength)
        return 0.0

    def get_mus(self, wavelength: float) -> float:
        """Returns the scattering coefficient for a given wavelength."""
        if self.scatterer and hasattr(self.scatterer, "get_mus"):
            return self.scatterer.get_mus(wavelength)
        return 0.0

    def get_optical_properties(self, wavelength: Union[float, List[float], np.ndarray]) -> Union[OpticalProperties, List[OpticalProperties], np.ndarray]:
        """Returns the optical properties for a given wavelength or array of wavelengths."""
        if isinstance(wavelength, (list, np.ndarray)):
            wavelength_array = np.asarray(wavelength)
            op_array = [self._compute_single_optical_properties(w) for w in wavelength_array]
            if isinstance(wavelength, np.ndarray):
                return np.array(op_array)
            return op_array
        return self._compute_single_optical_properties(wavelength)

    def _compute_single_optical_properties(self, wavelength: float) -> OpticalProperties:
        musp = self.get_musp(wavelength)
        mua = self.get_mua(wavelength)
        g = self.get_g(wavelength)
        n = self.n
        return OpticalProperties(mua, musp, g, n)


class TissueProvider:
    """Tissue provider class."""

    @staticmethod
    def create_absorbers(tissue_type: TissueType) -> List[Any]:
        """Creates standard templates lists of absorbers for the specified tissue type."""
        default_absorber_dictionary = {
            TissueType.Skin: {
                ChromophoreType.Hb: 28.4,
                ChromophoreType.HbO2: 22.4,
                ChromophoreType.H2O: 0.7,
                ChromophoreType.Fat: 0.0,
                ChromophoreType.Melanin: 0.0051,
            },
            TissueType.BreastPreMenopause: {
                ChromophoreType.Hb: 6.9,
                ChromophoreType.HbO2: 19.6,
                ChromophoreType.H2O: 0.345,
                ChromophoreType.Fat: 0.41,
            },
            TissueType.BreastPostMenopause: {
                ChromophoreType.Hb: 3.75,
                ChromophoreType.HbO2: 11.25,
                ChromophoreType.H2O: 0.205,
                ChromophoreType.Fat: 0.585,
            },
            TissueType.BrainWhiteMatter: {
                ChromophoreType.Hb: 24,
                ChromophoreType.HbO2: 56,
                ChromophoreType.H2O: 0.80,
                ChromophoreType.Fat: 0.12,
            },
            TissueType.BrainGrayMatter: {
                ChromophoreType.Hb: 24,
                ChromophoreType.HbO2: 56,
                ChromophoreType.H2O: 0.80,
                ChromophoreType.Fat: 0.12,
            },
            TissueType.Liver: {
                ChromophoreType.Hb: 66,
                ChromophoreType.HbO2: 124,
                ChromophoreType.H2O: 0.87,
                ChromophoreType.Fat: 0.02,
            },
            TissueType.IntralipidPhantom: {
                ChromophoreType.Nigrosin: 0.01,
            },
            TissueType.PolystyreneSpherePhantom: {
                ChromophoreType.Nigrosin: 0.01,
            },
            TissueType.Custom: {
                ChromophoreType.Hb: 20,
                ChromophoreType.HbO2: 20,
                ChromophoreType.H2O: 0.0,
                ChromophoreType.Fat: 0.0,
                ChromophoreType.Melanin: 0.0,
            }
        }

        absorber_dict = default_absorber_dictionary.get(tissue_type, {})
        """
        Group all chromophores into a single direct chrom_absorber collection instance
        matching class structure
        """
        chrom_names = [chromophore.name for chromophore in absorber_dict.keys()]
        concentrations = {chromophore.name: conc for chromophore, conc in absorber_dict.items()}

        absorber_instance = chrom_absorber(*chrom_names)
        # Attach default concentrations for preset usage
        absorber_instance.default_concentrations = concentrations

        # Override get_mua wrapper to automatically apply these concentrations if called from tissue
        original_get_mua = absorber_instance.get_mua
        absorber_instance.get_mua = lambda wl: original_get_mua(wl, concentrations)

        return [absorber_instance]

    @staticmethod
    def create_scatterer(tissue_type: TissueType) -> Any:
        """Sets the scatterer type for the specified tissue type."""
        if tissue_type in {
            TissueType.Skin,
            TissueType.Liver,
            TissueType.BrainWhiteMatter,
            TissueType.BrainGrayMatter,
            TissueType.BreastPreMenopause,
            TissueType.BreastPostMenopause,
            TissueType.Custom,
        }:
            return PowerLawScatterer(tissue_type)
        elif tissue_type == TissueType.IntralipidPhantom:
            return IntralipidScatterer()
        elif tissue_type == TissueType.PolystyreneSpherePhantom:
            return MieScatterer()
        else:
            raise ValueError(f"Unsupported tissueType: {tissue_type}")
