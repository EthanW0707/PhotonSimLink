from typing import Protocol

class IScatterer(Protocol):
    """Interface contract for all Scatterer implementations."""

    @property
    def scatterer_type(self):
        """The scatterer type."""
        ...

    def get_g(self, wavelength: float) -> float:
        """Returns the anisotropy coefficient for a given wavelength."""
        ...

    def get_mus(self, wavelength: float) -> float:
        """Returns the scattering coefficient for a given wavelength."""
        ...

    def get_musp(self, wavelength: float) -> float:
        """Returns the reduced scattering coefficient for a given wavelength."""
        ...
