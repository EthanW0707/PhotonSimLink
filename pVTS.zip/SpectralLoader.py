import os

def load_vts_resources_columnar(spectral_database, resources_dir="resources", scale_overrides=None):
    """
    Parses VTS Spectra.txt files containing headers like:
    %LAMBDA nm HbO2 1/(mm*uM) Hb 1/(mm*uM)

    spectral_database: pass in the SAME SpectralDatabase class object main.py
    already loaded (e.g. call this as
    load_vts_resources_columnar(SpectralDatabase, "resources", ...)).
    This file does NOT import or redefine SpectralDatabase itself -- avoids
    both the earlier duplicate-class bug and any relative-import issues,
    since main.py just hands in the one true class object directly.

    scale_overrides: optional dict of chromophore name -> multiplier applied
    to every raw value before registering, e.g. {"HbO2": 1/10000, "Hb": 1/10000}.
    Use this to correct a known-mislabeled header without touching the file
    or parsing unit strings at all.
    """
    scale_overrides = scale_overrides or {}
    spectra_path = os.path.join(resources_dir, "Spectra.txt")

    if not os.path.exists(spectra_path):
        print(f"Error: Could not find {spectra_path}")
        return

    wavelengths = []
    chromophore_data = {}
    chromophore_names = []

    with open(spectra_path, 'r', encoding='utf-8-sig') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith('%'):
                headers = line[1:].split()
                chromophore_names = []
                i = 2
                while i < len(headers) - 1:
                    chromophore_names.append(headers[i])
                    i += 2
                for name in chromophore_names:
                    chromophore_data[name] = []
                continue

            if line.startswith('#'):
                continue

            parts = line.replace(',', ' ').split()
            if len(parts) >= (1 + len(chromophore_names)):
                try:
                    wl = float(parts[0])
                    wavelengths.append(wl)
                    for idx, name in enumerate(chromophore_names):
                        chromophore_data[name].append(float(parts[idx + 1]))
                except ValueError:
                    continue

    for name, raw_values in chromophore_data.items():
        if not (wavelengths and raw_values):
            continue

        factor = scale_overrides.get(name, 1.0)
        if factor != 1.0:
            print(f"[SCALE] '{name}': applying manual factor {factor} to raw values to account for unit change")
        scaled_values = [v * factor for v in raw_values]

        spectral_database.register_spectrum(name, wavelengths, scaled_values)
        print(f"Successfully registered spectrum for: {name} ({len(wavelengths)} points)!")

    print("Columnar spectra loading complete!")
