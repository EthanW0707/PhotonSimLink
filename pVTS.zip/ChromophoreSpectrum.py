from typing import List, Optional, Dict
import numpy as np

class ChromophoreSpectrum:
    """
    Python equivalent of Vts.SpectralMapping.ChromophoreSpectrum
    Stores spectral data arrays and handles linear interpolation for a given wavelength.
    """
    def __init__(
        self,
        wavelengths: Optional[List[float]] = None,
        spectrum: Optional[List[float]] = None,
        name: str = "",
        coeff_type=None,
        abs_units=None,
        molar_unit=None,
        wavelength_unit=None
    ):
        # Fixed syntax error: added missing 'else []' for list fallback assignment
        self.wavelengths = wavelengths if wavelengths is not None else []
        self.spectrum = spectrum if spectrum is not None else []
        self.name = name
        self.chromophore_coefficient_type = coeff_type
        self.absorption_coefficient_unit = abs_units
        self.molar_unit = molar_unit
        self.wavelength_unit = wavelength_unit

    def get_spectral_value(self, wavelength: float) -> float:
        """
        Linearly interpolates known spectra to attain spectral value,
        matching the C# interpolation call.
        """
        if not self.wavelengths or not self.spectrum:
            return 0.0

        return float(np.interp(wavelength, self.wavelengths, self.spectrum))


class ChromophoreSpectrumDictionary(Dict[str, ChromophoreSpectrum]):
    """
    Python equivalent of Vts.SpectralMapping.ChromophoreSpectrumDictionary
    """
    pass


def to_dictionary(spectra: List[ChromophoreSpectrum]) -> ChromophoreSpectrumDictionary:
    """
    Python equivalent of the ToDictionary() extension method.
    """
    dictionary = ChromophoreSpectrumDictionary()
    for chromophore_spectrum in spectra:
        dictionary[chromophore_spectrum.name] = chromophore_spectrum
    return dictionary
