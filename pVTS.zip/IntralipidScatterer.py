class IntralipidScatterer:
    """
    An intralipid scatterer, based on Mie theory fit to experimental data by van Staveren et al.
    Python equivalent of Vts.SpectralMapping.IntralipidScatterer.
    """
    def __init__(self, volume_fraction: float = 0.01):
        self.volume_fraction = volume_fraction  # Triggers the setter validation below

    @property
    def scatterer_type(self) -> str:
        return "Intralipid"

    @property
    def volume_fraction(self) -> float:
        return self._volume_fraction

    @volume_fraction.setter
    def volume_fraction(self, value: float):
        # Enforce value to be bounded between [0, 1], matching the C# property logic
        if value > 1.0:
            value = 1.0
        elif value < 0.0:
            value = 0.0
        self._volume_fraction = value

    def get_g(self, wavelength: float) -> float:
        """Returns the anisotropy coefficient for a given wavelength."""
        return 1.1 - 5.8e-4 * wavelength

    def get_mus(self, wavelength: float) -> float:
        """Returns the scattering coefficient for a given wavelength."""
        return self._volume_fraction * 2.54e9 * (wavelength ** -2.4)

    def get_musp(self, wavelength: float) -> float:
        """Returns the reduced scattering coefficient for a given wavelength."""
        return self.get_mus(wavelength) * (1.0 - self.get_g(wavelength))
