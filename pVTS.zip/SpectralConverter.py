from enum import Enum
import re

class WavelengthUnit(Enum):
    Nanometers = 1
    Micrometers = 2
    Meters = 3
    InverseMeters = 4
    InverseCentimeters = 5

class AbsorptionCoefficientUnit(Enum):
    InverseMillimeters = 1
    InverseMeters = 2
    InverseCentimeters = 3
    InverseMicrometers = 4

class MolarUnit(Enum):
    None_ = 0
    Molar = 1
    MilliMolar = 2
    MicroMolar = 3
    NanoMolar = 4

class SpectralConverter:
    """Class to convert imported spectral data to uniform values."""

    @staticmethod
    def convert_wavelength(wavelength_value: float, unit: WavelengthUnit) -> float:
        """Method to convert wavelength values to nanometers."""
        if unit == WavelengthUnit.Nanometers:
            return wavelength_value
        elif unit == WavelengthUnit.Micrometers:
            return wavelength_value * 1000.0
        elif unit == WavelengthUnit.Meters:
            return wavelength_value * 1000000000.0
        elif unit == WavelengthUnit.InverseMeters:
            return 1000000000.0 / wavelength_value
        elif unit == WavelengthUnit.InverseCentimeters:
            return 10000000.0 / wavelength_value
        else:
            return wavelength_value

    @staticmethod
    def convert_coefficient(coefficient_value: float,
                            unit: AbsorptionCoefficientUnit = AbsorptionCoefficientUnit.InverseMillimeters,
                            molar_unit: MolarUnit = MolarUnit.MicroMolar) -> float:
        """Method to convert coefficient values to uniform units (target basis: 1/(mm*uM))."""
        if unit == AbsorptionCoefficientUnit.InverseMillimeters:
            coefficient = coefficient_value
        elif unit == AbsorptionCoefficientUnit.InverseMeters:
            coefficient = coefficient_value / 1000.0
        elif unit == AbsorptionCoefficientUnit.InverseCentimeters:
            coefficient = coefficient_value / 10.0
        elif unit == AbsorptionCoefficientUnit.InverseMicrometers:
            coefficient = coefficient_value * 1000.0
        else:
            coefficient = coefficient_value

        if molar_unit == MolarUnit.MilliMolar:
            return coefficient / 1000.0
        elif molar_unit == MolarUnit.Molar:
            return coefficient / 1000000.0
        elif molar_unit == MolarUnit.NanoMolar:
            return coefficient * 1000.0
        else:  # MicroMolar or None
            return coefficient

    @staticmethod
    def get_wavelength_unit(wavelength_unit_str: str) -> WavelengthUnit:
        """Passes a text string of wavelength unit and returns the relevant enum."""
        match = re.search(r'([a-zA-Z/1]+)', wavelength_unit_str)
        if match:
            val = match.group(1).lower()
            if val == "nm":
                return WavelengthUnit.Nanometers
            elif val == "um":
                return WavelengthUnit.Micrometers
            elif val == "m":
                return WavelengthUnit.Meters
            elif val == "1/m":
                return WavelengthUnit.InverseMeters
            elif val == "1/cm":
                return WavelengthUnit.InverseCentimeters
        raise ValueError(f"Not a valid wavelength unit: {wavelength_unit_str!r}")

    @staticmethod
    def get_wavelength_unit_string(wavelength_unit: WavelengthUnit) -> str:
        """Passes an enum of WavelengthUnit and returns a string."""
        if wavelength_unit == WavelengthUnit.InverseCentimeters:
            return "1/cm"
        elif wavelength_unit == WavelengthUnit.Nanometers:
            return "nm"
        elif wavelength_unit == WavelengthUnit.Micrometers:
            return "um"
        elif wavelength_unit == WavelengthUnit.Meters:
            return "m"
        elif wavelength_unit == WavelengthUnit.InverseMeters:
            return "1/m"
        else:
            raise ValueError("Unknown wavelength unit")

    @staticmethod
    def get_absorption_coefficient_unit(absorption_coefficient_unit_str: str) -> AbsorptionCoefficientUnit:
        """Passes a text string of absorption coefficient unit and returns the relevant enum."""
        match = re.search(r'1/\(?([a-zA-Z\*]+)\)?', absorption_coefficient_unit_str)
        if not match:
            raise ValueError(f"Not a valid absorption coefficient unit: {absorption_coefficient_unit_str!r}")

        units = match.group(1)
        unit_parts = units.split('*')
        base_unit = unit_parts[0].lower()

        if base_unit == "mm":
            return AbsorptionCoefficientUnit.InverseMillimeters
        elif base_unit == "cm":
            return AbsorptionCoefficientUnit.InverseCentimeters
        elif base_unit == "m":
            return AbsorptionCoefficientUnit.InverseMeters
        elif base_unit == "um":
            return AbsorptionCoefficientUnit.InverseMicrometers
        else:
            raise ValueError(f"Not a valid absorption coefficient unit: {absorption_coefficient_unit_str!r}")

    @staticmethod
    def get_molar_unit(molar_unit_str: str) -> MolarUnit:
        """
        Passes a text string of molar unit and returns the relevant enum.

        FIXED: previously did an exact, case-sensitive string match against
        "M"/"mM"/"uM"/"nM". A header written as "1/(mm*UM)" (or any other
        capitalization variant) would fail every comparison and silently
        fall through to MolarUnit.None_ -- which skips the /1,000,000 (or
        /1,000) scaling in convert_coefficient entirely. That is the root
        cause of mua values coming out ~1,000,000x too high: a real
        per-Molar or per-milliMolar coefficient was silently treated as
        if it were already per-microMolar with no error raised anywhere.

        Now: case-insensitive matching, and raises loudly if a molar
        component IS present but doesn't match any known unit, instead of
        quietly treating an unrecognized unit the same as "no unit at all".
        """
        match = re.search(r'1/\(*([a-zA-Z\*]+)\)*', molar_unit_str)
        if not match:
            return MolarUnit.None_

        units = match.group(1)
        if "*" not in units:
            return MolarUnit.None_

        unit_parts = units.split('*')
        if len(unit_parts) < 2:
            return MolarUnit.None_

        molar_str = unit_parts[1].strip().lower()

        if molar_str == "m":
            return MolarUnit.Molar
        elif molar_str == "mm":
            return MolarUnit.MilliMolar
        elif molar_str == "um":
            return MolarUnit.MicroMolar
        elif molar_str == "nm":
            return MolarUnit.NanoMolar
        else:
            raise ValueError(
                f"Unrecognized molar unit token {unit_parts[1]!r} in {molar_unit_str!r} "
                f"-- refusing to silently treat this as unscaled data."
            )

    @staticmethod
    def get_spectral_unit(molar_unit: MolarUnit, absorption_coefficient_unit: AbsorptionCoefficientUnit) -> str:
        """Passes the molar unit enum and absorption coefficient enum and returns it as a string."""
        if molar_unit == MolarUnit.None_:
            m_u = ""
        elif molar_unit == MolarUnit.Molar:
            m_u = "M"
        elif molar_unit == MolarUnit.MilliMolar:
            m_u = "mM"
        elif molar_unit == MolarUnit.MicroMolar:
            m_u = "uM"
        elif molar_unit == MolarUnit.NanoMolar:
            m_u = "nM"
        else:
            raise ValueError("Unknown molar unit")

        if absorption_coefficient_unit == AbsorptionCoefficientUnit.InverseCentimeters:
            a_cu = "cm"
        elif absorption_coefficient_unit == AbsorptionCoefficientUnit.InverseMeters:
            a_cu = "m"
        elif absorption_coefficient_unit == AbsorptionCoefficientUnit.InverseMicrometers:
            a_cu = "um"
        elif absorption_coefficient_unit == AbsorptionCoefficientUnit.InverseMillimeters:
            a_cu = "mm"
        else:
            raise ValueError("Unknown absorption coefficient unit")

        if molar_unit == MolarUnit.None_:
            return "1/" + a_cu
        else:
            return f"1/({a_cu}*{m_u})"
