import os
import numpy as np

class SpectralDatabase:
    _spectra = {}

    @classmethod
    def register_spectrum(cls, name, wavelengths, values):
        cls._spectra[name] = {
            'wavelengths': np.array(wavelengths, dtype=float),
            'values': np.array(values, dtype=float)
        }

    @classmethod
    def get_spectrum_value(cls, name, wavelength):
        if name not in cls._spectra:
            return 0.0
        data = cls._spectra[name]
        return float(np.interp(wavelength, data['wavelengths'], data['values']))

    @classmethod
    def get_extinction_coefficient(cls, name, wavelength):
        return cls.get_spectrum_value(name, wavelength)

    @classmethod
    def get_spectrum(cls, name):
        if name not in cls._spectra:
            raise KeyError(f"Spectrum '{name}' not found in database.")
        return cls._spectra[name]

    @classmethod
    def get_spectra_from_file(cls, file_path_or_stream, convert=True):
        if file_path_or_stream is None:
            return None

        if isinstance(file_path_or_stream, (str, os.PathLike)):
            file_stream = open(file_path_or_stream, 'r', encoding='utf-8')
            should_close = True
        else:
            file_stream = file_path_or_stream
            should_close = False

        try:
            lines = [line.strip('\r\n') for line in file_stream.readlines()]
        finally:
            if should_close:
                file_stream.close()

        lines = [l for l in lines if l != ""]
        if not lines:
            raise ValueError("File stream is empty.")

        header_line = None
        data_line_idx = 0
        for idx, line in enumerate(lines):
            if line.startswith("%"):
                stripped = line.lstrip('%').strip()
                if stripped.upper().startswith("LAMBDA") or stripped.upper().startswith("WAVELENGTH"):
                    header_line = stripped
                    data_line_idx = idx + 1
                    break
            else:
                header_line = line
                data_line_idx = idx + 1
                break

        if not header_line:
            raise ValueError("Could not find a valid header line in file.")

        header_row = header_line.split('\t')
        if len(header_row) < 2:
            header_row = header_line.split()
            if len(header_row) < 2:
                raise ValueError("There are not enough columns in the header.")

        hcolumns = len(header_row)

        while data_line_idx < len(lines) and (lines[data_line_idx] == "" or lines[data_line_idx].startswith("%")):
            data_line_idx += 1

        if data_line_idx >= len(lines):
            raise ValueError("No data rows found in file.")

        sample_data_line = lines[data_line_idx]
        delimiter = '\t' if '\t' in sample_data_line else None

        row = sample_data_line.split(delimiter)
        columns = len(row)

        chromophore_metadata = []
        for i in range(1, hcolumns):
            parts = header_row[i].strip().split(' ', 1)
            name = parts[0]
            unit = parts[1] if len(parts) > 1 else ""
            chromophore_metadata.append({
                'name': name,
                'absorption_coefficient_unit': unit,
            })

        wavelengths = []
        values_list = [[] for _ in range(hcolumns - 1)]

        for idx in range(data_line_idx, len(lines)):
            line = lines[idx]
            if line == "" or line.startswith("%"):
                continue

            row = line.split(delimiter)
            if len(row) < columns:
                continue

            try:
                raw_wl = float(row[0])
                wavelengths.append(raw_wl)
                for i in range(columns - 1):
                    raw_val = float(row[i + 1])
                    values_list[i].append(raw_val)
            except ValueError:
                continue

        result_dict = {}
        for i, meta in enumerate(chromophore_metadata):
            name = meta['name']
            if len(wavelengths) > 0 and len(values_list[i]) > 0:
                final_wavelengths = np.array(wavelengths, dtype=float)
                final_values = np.array(values_list[i], dtype=float)
                cls.register_spectrum(name, final_wavelengths, final_values)
                result_dict[name] = cls._spectra[name]

        return result_dict

    @classmethod
    def append_database_from_file(cls, file_path_or_stream):
        return cls.get_spectra_from_file(file_path_or_stream, convert=True)
